import pandas as pd
import os
os.chdir(os.path.dirname(os.path.abspath("D:\Omkar\VIT Stuff\Program files\Python\diabetes_prediction_dataset.csv")))
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

print("Current Working Directory:", os.getcwd())

# Load dataset
file_path = r"D:\Omkar\VIT Stuff\Program files\Python\diabetes_prediction_dataset.csv"
if not os.path.exists(file_path):
    raise FileNotFoundError(f"File not found: {file_path}")
df = pd.read_csv(file_path)
print(f"Total entries loaded: {len(df)}")

# Drop rows with missing target
df = df.dropna(subset=['diabetes'])

# Encode categorical/binary columns
for col in ['heart_disease', 'hypertension', 'diabetes']:
    if df[col].dtype == 'object':
        df[col] = LabelEncoder().fit_transform(df[col])

# Scale numeric columns
num_cols = ['age', 'bmi', 'HbA1c_level', 'blood_glucose_level']
scaler = StandardScaler()
df[num_cols] = scaler.fit_transform(df[num_cols])

# Define features and target
X = df[['age', 'heart_disease', 'hypertension', 'bmi', 'HbA1c_level', 'blood_glucose_level']]
y = df['diabetes']

# Split into 70% training and 30% testing
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Models to evaluate
models = {
    'Decision Tree': DecisionTreeClassifier(random_state=42),
    'Naive Bayes': GaussianNB(),
    'Random Forest': RandomForestClassifier(random_state=42)
}

best_model_name = None
best_model = None
best_accuracy = 0

print("\nModel Evaluation on Test Data:")
for name, model in models.items():
    model.fit(X_train, y_train)
    preds = model.predict(X_test)

    acc = accuracy_score(y_test, preds)
    prec = precision_score(y_test, preds)
    rec = recall_score(y_test, preds)
    f1 = f1_score(y_test, preds)

    print(f"\n{name}:")
    print(f"  Accuracy : {acc * 100:.2f}%")
    print(f"  Precision: {prec * 100:.2f}%")
    print(f"  Recall   : {rec * 100:.2f}%")
    print(f"  F1 Score : {f1 * 100:.2f}%")

    if acc > best_accuracy:
        best_accuracy = acc
        best_model_name = name
        best_model = model

print(f"\nBest model based on Accuracy: {best_model_name} (Accuracy = {best_accuracy * 100:.2f}%)")

# Assume `best_model` is your final trained model
import pickle

# Create the 'model' directory if it doesn't exist
os.chdir(r"D:\Omkar\VIT Stuff\Program files\My_project")
model_dir = 'model'
os.makedirs('model', exist_ok=True)

# Save the best model
model_path = os.path.join(model_dir, 'diabetes_model.pkl')
with open(model_path, 'wb') as f:
    pickle.dump(best_model, f)
print(f"Model saved to {model_path}")

# Save the scaler
scaler_path = os.path.join(model_dir, 'scaler.pkl')
with open(scaler_path, 'wb') as f:
    pickle.dump(scaler, f)
print(f"Scaler saved to {scaler_path}")

# Verify files were created
print("Files in model directory:", os.listdir(model_dir))