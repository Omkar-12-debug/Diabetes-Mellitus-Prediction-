from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import os
import pickle
from sklearn.preprocessing import StandardScaler
import numpy as np

app = Flask(__name__)

# Load the trained model and scaler
try:
    # Load model
    with open('model/diabetes_model.pkl', 'rb') as f:
        model = pickle.load(f)
    
    # Load scaler
    with open('model/scaler.pkl', 'rb') as f:
        scaler = pickle.load(f)
    print("Model and scaler loaded successfully")

except Exception as e:
    print(f"Error loading model/scaler: {e}")
    model = None
    scaler = None

def validate_input(data):
    """Validate and convert form input data"""
    try:
        validated = {
            'age': float(data.get('age', 0)),
            'bmi': float(data.get('bmi', 0)),
            'blood_glucose_level': float(data.get('blood_glucose_level', 0)),
            'HbA1c_level': float(data.get('HbA1c_level', 0)),
            'hypertension': int(data.get('hypertension', 0)),
            'heart_disease': int(data.get('heart_disease', 0))
        }
        
        # Basic validation
        if validated['age'] <= 0 or validated['age'] > 120:
            raise ValueError("Age must be between 1 and 120")
        if validated['bmi'] <= 10 or validated['bmi'] > 50:
            raise ValueError("BMI must be between 10 and 50")
            
        return validated
    except ValueError as e:
        raise ValueError(f"Invalid input: {str(e)}")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/methodology')
def methodology():
    return render_template('methodology.html')

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        try:
            print("Form data received:", request.form)  # Debugging
            
            # Get and validate form data
            age = float(request.form['age'])
            bmi = float(request.form['bmi'])
            blood_glucose_level = float(request.form['blood_glucose_level'])
            HbA1c_level = float(request.form['HbA1c_level'])
            hypertension = int(request.form['hypertension'])
            heart_disease = int(request.form['heart_disease'])
            
            print("Form data parsed successfully")  # Debugging
            
            # Check if model and scaler are loaded
            if model is None or scaler is None:
                raise Exception("Model or scaler not loaded")
            
            # Prepare input data
            input_data = pd.DataFrame({
                'age': [age],
                'heart_disease': [heart_disease],
                'hypertension': [hypertension],
                'bmi': [bmi],
                'HbA1c_level': [HbA1c_level],
                'blood_glucose_level': [blood_glucose_level]
            })
            print("Input data prepared:", input_data)  # Debugging
            
            # Scale numerical features
            numerical_cols = ['age', 'bmi', 'HbA1c_level', 'blood_glucose_level']
            input_data[numerical_cols] = scaler.transform(input_data[numerical_cols])
            print("Data scaled:", input_data)  # Debugging
            
            # Make prediction
            prediction = model.predict(input_data)[0]
            probability = model.predict_proba(input_data)[0][1]
            print("Prediction made:", prediction, "Probability:", probability)  # Debugging
            
            # Determine risk level
            if probability < 0.3:
                risk_level = "Low"
            elif probability < 0.7:
                risk_level = "Medium"
            else:
                risk_level = "High"
            
            return render_template('results.html', 
                                prediction=prediction,
                                probability=f"{probability*100:.1f}",
                                risk_level=risk_level,
                                age=age,
                                bmi=bmi,
                                blood_glucose_level=blood_glucose_level,
                                HbA1c_level=HbA1c_level,
                                hypertension=hypertension,
                                heart_disease=heart_disease)
            
        except Exception as e:
            print("Error during prediction:", str(e))  # Debugging
            return render_template('predict.html', error=str(e))
    
    return render_template('predict.html')

if __name__ == '__main__':
    app.run(debug=True)